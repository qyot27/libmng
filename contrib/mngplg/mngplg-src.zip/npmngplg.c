/* -*- Mode: C; tab-width: 4; -*- */
/* mngplg.c
 * MNG browser plugin
 * By Jason Summers
 * Based on libmng by Gerard Juyn
 */

#include <windows.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <malloc.h>
#include <stdarg.h>

#include "npupp.h"
#include "npapi.h"
#include "resource.h"
#include "libmng.h"


#define DLLFILENAME "npmngplg.dll"
#define PRGNAME "MNGPLG"
#define VERS    "0.1.0"

#define uchar unsigned char

/* plugin-specific data */
typedef struct pluginstruct_
{
	NPWindow*  fWindow;
	uint16     fMode;
	HWND       fhWnd;
	WNDPROC    fDefaultWindowProc;
	NPP        instance;

	mng_handle mng;
	HANDLE mngfile;
	char mngfn[MAX_PATH];

	int diblinesize;
	int dibsize;
	uchar *lpdib;    // pointer to header section of dib
	uchar *lpdibbits;   // pointer to "bits" section of dib (follows the header)
	LPBITMAPINFOHEADER lpdibinfo;  // alias for lpdib
	uchar bg_r,bg_g,bg_b;  // background color
	char url[MAX_PATH];  /* the url of the stream */

} PluginInstance;


/* global variables */

extern NPNetscapeFuncs* g_pNavigatorFuncs;

const char* gInstanceLookupString = "pdata";
HMODULE hInst;
HMENU hmenuContext=NULL;

/* forward declarations of functions */
LRESULT CALLBACK DlgProcAbout(HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK PluginWindowProc(HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam);
void ContextMenu(PluginInstance *This, int x, int y, HWND hwnd);


/* ----------------------------------------------------------------------- */

/* safer version of strncpy, which always null-terminates strings */
void Strncpy(char *dest, const char *src, int len)
{
   if(src) {
      strncpy(dest,src,len-1);
      dest[len-1]='\0';
   }
   else dest[0]='\0';
}

void warn(PluginInstance *This, char *fmt, ...)
{
	va_list ap;
	char buf[2048];
	HWND hwnd;

	va_start(ap, fmt);
	vsprintf(buf,fmt, ap);
	va_end(ap);

	if(This) hwnd= This->fhWnd;
	else hwnd=NULL;

	MessageBox(hwnd,buf,"MNG Plug-in",MB_OK|MB_ICONWARNING);
}

/* ----------------------------------------------------------------------- */
//    MNG callbacks

mng_ptr memallocfunc(mng_uint32 n)
{
	return GlobalAlloc(GPTR,(DWORD)n);
}


void memfreefunc(mng_ptr p, mng_uint32 n)
{
	GlobalFree( (HGLOBAL)p );
}


void cbOpenStream (mng_handle mng)
{
	PluginInstance *This;
	This = (PluginInstance*) mng_get_userdata(mng);

	This->mngfile=CreateFile(This->mngfn,GENERIC_READ,FILE_SHARE_READ,NULL,
		OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);

	if(This->mngfile==INVALID_HANDLE_VALUE) {
		warn(This,"Can't open file");
		// what to do here??
	}
}

void cbCloseStream (mng_handle mng)
{
	PluginInstance *This;
	This = (PluginInstance*) mng_get_userdata(mng);

	if(This->mngfile != INVALID_HANDLE_VALUE) { CloseHandle(This->mngfile); }
	This->mngfile=INVALID_HANDLE_VALUE;
}


mng_retcode cbReadData (mng_handle mng,mng_ptr pBuf,
                      mng_uint32 Buflen,mng_uint32 *pRead)
{
	DWORD bytesread;
	PluginInstance *This;
	This = (PluginInstance*) mng_get_userdata(mng);

	ReadFile(This->mngfile,(void*)pBuf,Buflen,&bytesread,NULL);
	// check for errors here

	(*pRead)= bytesread;
	return 0;   // == success...
}


void cbProcessHeader(mng_handle mng,mng_uint32 iWidth,mng_uint32 iHeight)
{
	PluginInstance *This;
	This = (PluginInstance*) mng_get_userdata(mng);

	This->diblinesize = (((iWidth * 24)+31)/32)*4;
	This->dibsize = sizeof(BITMAPINFOHEADER) + This->diblinesize*iHeight;
	This->lpdib = GlobalAlloc(GPTR,This->dibsize);
	This->lpdibinfo = (LPBITMAPINFOHEADER)This->lpdib;
	This->lpdibbits = &This->lpdib[sizeof(BITMAPINFOHEADER)];
	ZeroMemory((void*)This->lpdib,sizeof(BITMAPINFOHEADER));
	This->lpdibinfo->biSize = sizeof(BITMAPINFOHEADER);
	This->lpdibinfo->biWidth = iWidth;
	This->lpdibinfo->biHeight = iHeight;
	This->lpdibinfo->biPlanes = 1;
	This->lpdibinfo->biBitCount = 24;

	mng_set_canvasstyle (mng, MNG_CANVAS_BGR8);
}


mng_ptr cbGetCanvasLine (mng_handle mng, mng_uint32 iLinenr)
{
	uchar *pp;

	PluginInstance *This;
	This = (PluginInstance*) mng_get_userdata(mng);

	pp = (&This->lpdib[(This->lpdibinfo->biHeight-1-iLinenr)*This->diblinesize + sizeof(BITMAPINFOHEADER)]);
	return (mng_ptr) pp;
}

void cbImageRefresh (mng_handle mng, mng_uint32 iTop, mng_uint32 iLeft,
                       mng_uint32 iBottom, mng_uint32 iRight)
{
	PluginInstance *This;
	This = (PluginInstance*) mng_get_userdata(mng);

	if(This->fhWnd) {
		// fix this to update the correct rectangle
		InvalidateRect(This->fhWnd,NULL,FALSE);
		UpdateWindow(This->fhWnd);
	}
}

mng_uint32 cbGetTickCount (mng_handle mng)
{
	return GetTickCount();
}


void cbSetTimer (mng_handle mng,mng_uint32 iMsecs)
{
	PluginInstance *This;
	This = (PluginInstance*) mng_get_userdata(mng);

	if(This->fhWnd) {
		SetTimer(This->fhWnd,1,(UINT)iMsecs,NULL);
	}
}

/* ----------------------------------------------------------------------- */

void my_init_mng(PluginInstance *This)
{
	mng_retcode rv;

	This->mng = mng_initialize((mng_int32)This,memallocfunc,memfreefunc,NULL);
	rv=mng_set_srgb(This->mng,1);

	rv=mng_setcb_openstream    (This->mng, cbOpenStream   );
	rv=mng_setcb_closestream   (This->mng, cbCloseStream  );
	rv=mng_setcb_readdata      (This->mng, cbReadData     );
	rv=mng_setcb_processheader (This->mng, cbProcessHeader);
	rv=mng_setcb_getcanvasline (This->mng, cbGetCanvasLine);
	rv=mng_setcb_refresh       (This->mng, cbImageRefresh );
	rv=mng_setcb_gettickcount  (This->mng, cbGetTickCount );
	rv=mng_setcb_settimer      (This->mng, cbSetTimer     );

	rv=mng_set_bgcolor (This->mng, This->bg_r, This->bg_g, This->bg_b);

	mng_readdisplay(This->mng);
}


/* Global initialization */
NPError NPP_Initialize(void)
{
	hInst=GetModuleHandle(DLLFILENAME);
	if(!hInst) {
		warn(NULL,"Cannot load resources. Make sure plug-in file is named %s",DLLFILENAME);
	}
	hmenuContext=LoadMenu(hInst,"CONTEXTMENU");
	return NPERR_NO_ERROR;
}

/* Global shutdown */
void NPP_Shutdown(void)
{
	if(hmenuContext) DestroyMenu(hmenuContext);
}


uchar gethex(const char *s)
{
	int v0,v1;
	v0=v1=0; 
	if(s[0]>='a' && s[0]<='f') v0=s[0]-87;
	if(s[0]>='A' && s[0]<='F') v0=s[0]-55;
	if(s[0]>='0' && s[0]<='9') v0=s[0]-48;
	if(s[1]>='a' && s[1]<='f') v1=s[1]-87;
	if(s[1]>='A' && s[1]<='F') v1=s[1]-55;
	if(s[1]>='0' && s[1]<='9') v1=s[1]-48;
	return (uchar)(v0*16+v1);
}

void hexcolor2rgb(const char *s,uchar *r, uchar *g, uchar *b)
{
	if(strlen(s)!=7) return;
	if(s[0]!='#') return;
	(*r)=gethex(&s[1]);
	(*g)=gethex(&s[3]);
	(*b)=gethex(&s[5]);
}


/* Once-per-instance initialization */
NPError NPP_New(NPMIMEType pluginType,NPP instance,uint16 mode,
		int16 argc,char* argn[],char* argv[],NPSavedData* saved)
{
	PluginInstance* This;
	int i;
	
	if (instance == NULL) {
		return NPERR_INVALID_INSTANCE_ERROR;
	}
	/* instance->pdata = NPN_MemAlloc(sizeof(PluginInstance)); */
	instance->pdata = GlobalAlloc(GPTR,sizeof(PluginInstance));

	This = (PluginInstance*) instance->pdata;
	if (This == NULL) {
	    return NPERR_OUT_OF_MEMORY_ERROR;
	}

	This->bg_r = This->bg_g = This->bg_b = 0xff;

	/* examine the <embed> tag arguments */
	for(i=0;i<argc;i++) {
		if(!_stricmp(argn[i],"bgcolor")) {
			hexcolor2rgb(argv[i],&This->bg_r,&This->bg_g,&This->bg_b);
		}
	}

	/* record some info for later lookup */
	This->fWindow = NULL;
	This->fMode = mode;
	
	This->fhWnd = NULL;
	This->fDefaultWindowProc = NULL;
	This->instance = instance;  /* save the instance id for reverse lookups */

	This->mng=0;
	This->lpdib=NULL;
	This->mngfile=INVALID_HANDLE_VALUE;

//	This->lpdib=NULL;
//	This->diballoc=0;
//	This->dibused=0;
//	This->status=ST_NOTLOADED;
//	This->prevpainted=0;

//	my_init_mng(This);

	return NPERR_NO_ERROR;
}

NPError NPP_Destroy(NPP instance, NPSavedData** save)
{
	PluginInstance* This;

	if (instance == NULL) return NPERR_INVALID_INSTANCE_ERROR;
	This = (PluginInstance*) instance->pdata;

	if(!This) return NPERR_INVALID_INSTANCE_ERROR;

	if(This->mng) {
		mng_cleanup(&This->mng); 
		This->mng=0;
	}
	if(This->mngfile!=INVALID_HANDLE_VALUE) {
		CloseHandle(This->mngfile);
		This->mngfile=INVALID_HANDLE_VALUE;
	}
	if(This->lpdib) {
		GlobalFree(This->lpdib);
		This->lpdib=NULL;
	}

	if( This->fhWnd ) { /* If we have a window, clean it up. */
		SetWindowLong( This->fhWnd, GWL_WNDPROC, (LONG)This->fDefaultWindowProc);
		This->fDefaultWindowProc = NULL;
		This->fhWnd = NULL;
	}


	if (This != NULL) {
		if(instance->pdata) GlobalFree(instance->pdata);
		instance->pdata = NULL;
	}

	return NPERR_NO_ERROR;
}

jref NPP_GetJavaClass(void)
{
	return NULL;
}

/* Browser is providing us with a window */
NPError NPP_SetWindow(NPP instance, NPWindow* window)
{
	NPError result = NPERR_NO_ERROR;
	PluginInstance* This;

	if (instance == NULL) return NPERR_INVALID_INSTANCE_ERROR;

	This = (PluginInstance*) instance->pdata;

	if( This->fhWnd != NULL ) {   /* If we already have a window... */

		if( (window == NULL) || ( window->window == NULL ) ) {
			/* There is now no window to use. get rid of the old
			 * one and exit. */
			SetWindowLong( This->fhWnd, GWL_WNDPROC, (LONG)This->fDefaultWindowProc);
			This->fDefaultWindowProc = NULL;
			This->fhWnd = NULL;
			This->fWindow=window;
			return NPERR_NO_ERROR;
		}

		else if ( This->fhWnd == (HWND) window->window ) {
			/* The new window is the same as the old one. Redraw and get out. */
			This->fWindow=window;

			InvalidateRect( This->fhWnd, NULL, FALSE );
			/* UpdateWindow( This->fhWnd ); */
			return NPERR_NO_ERROR;
		}
		else {
			/* Unsubclass the old window, so that we can subclass the new
			 * one later. */
			SetWindowLong( This->fhWnd, GWL_WNDPROC, (LONG)This->fDefaultWindowProc);
			This->fDefaultWindowProc = NULL;
			This->fhWnd = NULL;
		}
	}
	else if( (window == NULL) || ( window->window == NULL ) ) {
		/* We can just get out of here if there is no current
		 * window and there is no new window to use. */
		This->fWindow=window;

		return NPERR_NO_ERROR;
	}

	/* Subclass the new window so that we can begin drawing and
	 * receiving window messages. */
	This->fDefaultWindowProc = (WNDPROC)SetWindowLong( (HWND)window->window, GWL_WNDPROC, (LONG)PluginWindowProc);
	This->fhWnd = (HWND) window->window;
	SetProp( This->fhWnd, gInstanceLookupString, (HANDLE)This);

	This->fWindow = window;

	InvalidateRect( This->fhWnd, NULL, TRUE );
	UpdateWindow( This->fhWnd );

	return result;
}

// browser is announcing its intent to send data to us
NPError NPP_NewStream(NPP instance,NPMIMEType type,NPStream *stream, 
	      NPBool seekable,uint16 *stype) {
	PluginInstance* This;

	if(instance==NULL)
		return NPERR_INVALID_INSTANCE_ERROR;

	This = (PluginInstance*) instance->pdata;
	if(!This)
		return NPERR_GENERIC_ERROR;

	/* save the URL for later */
	Strncpy(This->url,stream->url,MAX_PATH);

	(*stype)=NP_ASFILE; // -- request stream to be given as a file

	return NPERR_NO_ERROR;
}

int32 NPP_WriteReady(NPP instance, NPStream *stream)
{
	/* Number of bytes ready to accept in NPP_Write() */
	/* We can handle any amount, so just return some really big number. */
	return (int32)0X0FFFFFFF;
}


int32 NPP_Write(NPP instance, NPStream *stream, int32 offset, int32 len, void *buffer)
{
	return len; /* The number of bytes accepted -- we always accept them all. */
}

/* DestroyStream gets called after the file has finished loading,
 */
NPError NPP_DestroyStream(NPP instance, NPStream *stream, NPError reason)
{
	return NPERR_NO_ERROR;
}


void NPP_StreamAsFile(NPP instance, NPStream *stream, const char* fname)
{
	PluginInstance* This;
	if (instance == NULL) return;
	This = (PluginInstance*) instance->pdata;

	// start displaying the file here
	Strncpy(This->mngfn,fname,MAX_PATH);

	my_init_mng(This);
}

/* Print embedded plug-in (via the browser's Print command) */
void NPP_Print(NPP instance, NPPrint* printInfo)
{
	return;
}


/*+++++++++++++++++++++++++++++++++++++++++++++++++
 * NPP_URLNotify:
 * Notifies the instance of the completion of a URL request. 
 +++++++++++++++++++++++++++++++++++++++++++++++++*/
void NPP_URLNotify(NPP instance, const char* url, NPReason reason, void* notifyData)
{
	return;
}


/*+++++++++++++++++++++++++++++++++++++++++++++++++
 * NPP_HandleEvent:

 * With normal windowed plugins, this is used only for Macs.

 * With windowless plugins, it is where everything happens.
 
  If the plug-in handles the event, the function should return true. 
  If the plug-in ignores the event, the function returns false. 

 +++++++++++++++++++++++++++++++++++++++++++++++++*/
int16 NPP_HandleEvent(NPP instance, void* event)
{
	return 0;
}

/**********************************************************************/



void AboutDialog(PluginInstance *This)
{
	DialogBoxParam(hInst,"ABOUTDLG",This->fhWnd,(DLGPROC)DlgProcAbout,(LPARAM)This);
}

void ContextMenu(PluginInstance *This, int x, int y, HWND hwnd)
{
	HMENU sub;
	int cmd;

	sub=GetSubMenu(hmenuContext,0);

	cmd=TrackPopupMenuEx(sub, TPM_LEFTALIGN|TPM_TOPALIGN|TPM_NONOTIFY|TPM_RETURNCMD|
		TPM_RIGHTBUTTON,x,y,hwnd,NULL);

	switch(cmd) {
/*	case ID_SAVEAS:   SaveImage(This);  break;
	case ID_COPYIMAGE:
		if(This->status==ST_LOADED && This->lpdib) {
			CopyToClipboard(This,(unsigned char*)This->lpdib,This->dibused,CF_DIB);
		}
		else {
			warn(This,"No image to copy");
		}
		break; */
	case ID_COPYURL:
/*		if(strlen(This->url)) {
			CopyToClipboard(This,This->url,strlen(This->url)+1,CF_TEXT);
		}
		else {
			warn(This,"No link to copy");
		} */
		break;
	case ID_VIEWIMAGE:
		if(strlen(This->url)) 
			NPN_GetURL(This->instance,This->url,"_self");
		break;
	case ID_ABOUT:   AboutDialog(This); break;

	}
}

/*+++++++++++++++++++++++++++++++++++++++++++++++++
 * PluginWindowProc
 * Handle the Windows window-event loop.
 +++++++++++++++++++++++++++++++++++++++++++++++++*/
LRESULT CALLBACK PluginWindowProc( HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam)
{
	static int count=0;
	char buf[50];
	PluginInstance* This = (PluginInstance*) GetProp(hWnd, gInstanceLookupString);
	if(!This) return DefWindowProc( hWnd, Msg, wParam, lParam);

	switch(Msg) {
//	case WM_ERASEBKGND:
			/* Disable background-erasing. It seems a little unreliable, so we'll
			 * do it ourselves in WM_PAINT */
//		return 1;

	case WM_CONTEXTMENU:
		ContextMenu(This,LOWORD(lParam),HIWORD(lParam), hWnd);
		return 0;

	case WM_PAINT:
		{
			PAINTSTRUCT paintStruct;
			HDC hdc;
			RECT rect;

			hdc = BeginPaint( hWnd, &paintStruct );

			GetClientRect(hWnd,&rect);

//			PaintBitmap(This, hdc, &rect, 1);

			if(This && This->lpdib) {

				StretchDIBits(hdc,
//					rect.left,rect.top,rect.right,rect.bottom, /* dest */
//					rect.left,rect.top,rect.right,rect.bottom, /* source  */
					0,0,This->lpdibinfo->biWidth,This->lpdibinfo->biHeight,
					0,0,This->lpdibinfo->biWidth,This->lpdibinfo->biHeight,
					&((BYTE*)(This->lpdib))[sizeof(BITMAPINFOHEADER)],
					(LPBITMAPINFO)This->lpdib,DIB_RGB_COLORS,SRCCOPY);
			}


			EndPaint( hWnd, &paintStruct );
		}
		return 0;

	case WM_TIMER:
		KillTimer(hWnd,1);     // should I do this?
		sprintf(buf,"%d",count++);
//		NPN_Status(This->instance,buf);
		if(This->mng) mng_display_resume(This->mng);
		return 0;

	}

	/* Forward unprocessed messages on to their original destination
	 * (the window proc we replaced) */
	return This->fDefaultWindowProc(hWnd, Msg, wParam, lParam);
}


LRESULT CALLBACK DlgProcAbout(HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam)
{
	char buf[4096],buf2[1024];

	switch(Msg) {
	case WM_INITDIALOG:
		{
			DWORD tabs[1];

			PluginInstance *This=(PluginInstance*)lParam;

			tabs[0]= 60;
			SendDlgItemMessage(hWnd,IDC_IMGINFO,EM_SETTABSTOPS,(WPARAM)1,(LPARAM)tabs);

			sprintf(buf,"MNGPLG Plug-in, Version %s\r\n%s"
#ifdef _DEBUG
				" DEBUG BUILD"
#endif
				"\r\nBy Jason Summers\r\n"
				"Based on libmng by Gerard Juyn\r\n"
				"Uses the zlib compression library\r\n"
				"This software is based in part on the work of the Independent JPEG Group.\r\n"
				"Uses the lcms color management library by Marti Maria"

				,VERS,__DATE__);
			SetDlgItemText(hWnd,IDC_PRGINFO,buf);

			sprintf(buf,"URL:\t%s\r\n",This->url);

			if(This->lpdib) {
				sprintf(buf2,"Dimensions:\t%d x %d\r\n",This->lpdibinfo->biWidth,
					This->lpdibinfo->biHeight);
				strcat(buf,buf2);
			}

			SetDlgItemText(hWnd,IDC_IMGINFO,buf);
		}
		return(TRUE);
	case WM_CLOSE:
		EndDialog(hWnd,0);
		return(TRUE);
	case WM_COMMAND:
		switch(wParam) {
		case IDOK:
		case IDCANCEL:
			EndDialog(hWnd,0);
			return(TRUE);
		}
	}
	return(FALSE);
}

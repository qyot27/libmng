/* -*- Mode: C; tab-width: 4; -*- */
/* mngplg.c
 * MNG browser plugin
 * By Jason Summers
 * Based on libmng by Gerard Juyn
 * Requires the "glue" files from Netscape's 4.0 plug-in SDK
 *   (npwin.cpp and include\*.h)
 */

#include <windows.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <malloc.h>
#include <stdarg.h>

#include "npupp.h"
#include "npapi.h"
#include "resource.h"

#define HAVE_BOOLEAN       // for libjpeg

#include "libmng.h"


#define DLLFILENAME "npmngplg.dll"
#define PRGNAME "MNGPLG"
#define VERS    "0.3.0"

#define uchar unsigned char

#define SRGB_PROFILE_LENGTH  3144


/* plugin-specific data */
typedef struct pluginstruct_
{
	NPWindow*  fWindow;
	uint16     fMode;
	HWND       fhWnd;
	WNDPROC    fDefaultWindowProc;
	NPP        instance;

	mng_handle mng;
	int loadstate;

#define STATE_INIT        0
#define STATE_LOADING     1  // stream opened
#define STATE_VALIDFRAME  2  // at least one frame has been displayed
#define STATE_LOADED      3  // image loaded; stream closed

	int diblinesize;
	DWORD dibsize;
	DWORD filesize;
	DWORD libmngpos;  // count of bytes that have been sent to libmng
	DWORD byteswanted;   // libmng asked for this many more bytes (add to libmngpos)

	uchar *mngdata;    // stores the MNG file in memory
	DWORD bytesloaded;  // bytes loaded
	DWORD bytesalloc;   // size of mngdata
	int needresume;   // if previous mng_readdisplay call returned NEEDMOREDATA

	uchar *lpdib;    // pointer to header section of dib
	uchar *lpdibbits;   // pointer to "bits" section of dib (follows the header)
	LPBITMAPINFOHEADER lpdibinfo;  // alias for lpdib
	int frozen;

	mng_uint16 bg_r,bg_g,bg_b;  // background color
	char url[MAX_PATH];  /* the url of the stream */

} PluginInstance;


/* global variables */

extern NPNetscapeFuncs* g_pNavigatorFuncs;

const char* gInstanceLookupString = "pdata";
HMODULE hInst;
HMENU hmenuContext=NULL;

/* forward declarations of functions */
LRESULT CALLBACK DlgProcAbout(HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK PluginWindowProc(HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam);
//void ContextMenu(PluginInstance *This, int x, int y, HWND hwnd);


/* ----------------------------------------------------------------------- */

/* safer version of strncpy, which always null-terminates strings */
void Strncpy(char *dest, const char *src, int len)
{
   if(src) {
      strncpy(dest,src,len-1);
      dest[len-1]='\0';
   }
   else dest[0]='\0';
}

void warn(PluginInstance *This, char *fmt, ...)
{
	va_list ap;
	char buf[2048];
	HWND hwnd;

	va_start(ap, fmt);
	vsprintf(buf,fmt, ap);
	va_end(ap);

	if(This) hwnd= This->fhWnd;
	else hwnd=NULL;

	MessageBox(hwnd,buf,"MNG Plug-in",MB_OK|MB_ICONWARNING);
}

/* ----------------------------------------------------------------------- */
//    MNG callbacks

mng_ptr memallocfunc(mng_uint32 n)
{
	return GlobalAlloc(GPTR,(DWORD)n);
}


void memfreefunc(mng_ptr p, mng_uint32 n)
{
	GlobalFree( (HGLOBAL)p );
}


mng_bool callback_openstream (mng_handle mng)
{
//	PluginInstance *This;
//	This = (PluginInstance*) mng_get_userdata(mng);
	return MNG_TRUE;
}

mng_bool callback_closestream (mng_handle mng)
{
	PluginInstance *This;
	This = (PluginInstance*) mng_get_userdata(mng);
	This->loadstate = STATE_LOADED;

	return MNG_TRUE;
}


mng_bool callback_readdata (mng_handle mng,mng_ptr pBuf,
                      mng_uint32 Buflen,mng_uint32 *pRead)
{
	PluginInstance *This;
	This = (PluginInstance*) mng_get_userdata(mng);

	// do we have enough data available?
	if(This->bytesloaded - This->libmngpos >= Buflen) {
		CopyMemory(pBuf,&This->mngdata[This->libmngpos],Buflen);
		(*pRead)= Buflen;
		This->libmngpos += Buflen;

		// temporary(?) workaround    FIXME
		if(This->filesize>0 && This->libmngpos >= This->filesize) {
			This->loadstate=STATE_LOADED;
//			cbCloseStream(mng);
		}

		This->byteswanted=0;
		return MNG_TRUE;
	}

	// else we don't yet have the data it's requesting
	(*pRead)=0;
	This->byteswanted=Buflen;
	return MNG_FALSE;
}


mng_bool callback_processheader(mng_handle mng,mng_uint32 iWidth,mng_uint32 iHeight)
{
	PluginInstance *This;
	This = (PluginInstance*) mng_get_userdata(mng);

	This->diblinesize = (((iWidth * 24)+31)/32)*4;
	This->dibsize = sizeof(BITMAPINFOHEADER) + This->diblinesize*iHeight;
	This->lpdib = GlobalAlloc(GPTR,This->dibsize);
	This->lpdibinfo = (LPBITMAPINFOHEADER)This->lpdib;
	This->lpdibbits = &This->lpdib[sizeof(BITMAPINFOHEADER)];
	ZeroMemory((void*)This->lpdib,sizeof(BITMAPINFOHEADER));
	This->lpdibinfo->biSize = sizeof(BITMAPINFOHEADER);
	This->lpdibinfo->biWidth = iWidth;
	This->lpdibinfo->biHeight = iHeight;
	This->lpdibinfo->biPlanes = 1;
	This->lpdibinfo->biBitCount = 24;

	mng_set_canvasstyle (mng, MNG_CANVAS_BGR8);
	return MNG_TRUE;
}


mng_ptr callback_getcanvasline (mng_handle mng, mng_uint32 iLinenr)
{
	uchar *pp;

	PluginInstance *This;
	This = (PluginInstance*) mng_get_userdata(mng);
	pp = (&This->lpdibbits[(This->lpdibinfo->biHeight-1-iLinenr)*This->diblinesize]);
	return (mng_ptr) pp;
}

mng_bool callback_refresh (mng_handle mng, mng_uint32 iTop, mng_uint32 iLeft,
                       mng_uint32 iBottom, mng_uint32 iRight)
{
	PluginInstance *This;
	RECT rect;

	This = (PluginInstance*) mng_get_userdata(mng);

	if(This->loadstate<STATE_VALIDFRAME) This->loadstate=STATE_VALIDFRAME;

	if(This->fhWnd) {

		rect.left= iLeft;
		rect.top= iTop;
		rect.right= iRight;
		rect.bottom= iBottom;

		if(This->loadstate < STATE_LOADED) {
			// FIXME?? workaround libmng quirk??
			InvalidateRect(This->fhWnd,NULL,FALSE);
		}
		else {
			InvalidateRect(This->fhWnd,&rect,FALSE);
		}
		
		UpdateWindow(This->fhWnd);
	}
	return MNG_TRUE;
}

mng_uint32 callback_gettickcount (mng_handle mng)
{
	return GetTickCount();
}


mng_bool callback_settimer (mng_handle mng,mng_uint32 iMsecs)
{
	PluginInstance *This;
	This = (PluginInstance*) mng_get_userdata(mng);

	if(This->fhWnd) {
		if(!SetTimer(This->fhWnd,1,(UINT)iMsecs,NULL)) {
			warn(This,"Unable to create a timer for animation");
			This->frozen=1;
			return MNG_FALSE;
		}
	}
	return MNG_TRUE;
}

/* ----------------------------------------------------------------------- */
int file_exists(const char *fn)
{
   HANDLE h;

   // try to open with no access
   h=CreateFile(fn,0,FILE_SHARE_READ,NULL,OPEN_EXISTING,
      FILE_ATTRIBUTE_NORMAL,NULL);
   if(h == INVALID_HANDLE_VALUE) { return 0; }
   CloseHandle(h);
   return 1;
}

void handle_read_error(PluginInstance *This, mng_retcode rv)
{
	// FIXME dialog boxes really aren't acceptable here
	switch(rv) {
	case MNG_NOERROR:
		break;

	case MNG_NEEDMOREDATA:
		This->needresume=1;
		break;

	case MNG_INVALIDSIG:
		warn(This,"Invalid or missing MNG file (maybe a 404 Not Found error)");
		break;

	default:
		warn(This,"Error %d reported by libmng",(int)rv);
	}
}

int init_color_management(PluginInstance *This)
{
	HRSRC hrsrcSRGB;
	HGLOBAL hglobalSRGB;
	mng_ptr lpSRGB;
	char srgb_icm_filename[MAX_PATH];
	HKEY key;
	DWORD datasize,datatype;
	long r;

	// first, try to find an srgb profile .icm file on the user's system
	if(RegOpenKeyEx(HKEY_LOCAL_MACHINE,
		"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\SETUP", // this is really just a guess
		0,KEY_READ,&key)!=ERROR_SUCCESS) {
		goto useinternal;
	}

	datasize=MAX_PATH-50;
	r=RegQueryValueEx(key,"ICMPATH",NULL,&datatype,
		(LPBYTE)srgb_icm_filename,&datasize);
	RegCloseKey(key);

	if(r!=ERROR_SUCCESS) {
		goto useinternal;
	}

	strcat(srgb_icm_filename,"\\sRGB Color Space Profile.icm");
	if(file_exists(srgb_icm_filename)) {
		if( mng_set_srgb(This->mng, MNG_TRUE) ) {
			warn(This,"mng_set_srgb failed");
			return 0;
		}
		if( mng_set_outputprofile (This->mng, srgb_icm_filename) ) {
			warn(This,"mng_set_outputprofile failed");
			return 0;
		}
		return 1;
	}

	// if we can't find one, use the one embedded in the plugin
useinternal:

	hrsrcSRGB = FindResource(hInst,"SRGBDATA",RT_RCDATA);
	hglobalSRGB = LoadResource(hInst,hrsrcSRGB);

	// 
	if(SizeofResource(hInst,hrsrcSRGB)<SRGB_PROFILE_LENGTH) {
		warn(This,"internal: incorrect sRGB profile size");
		return 0;
	}

	lpSRGB = (mng_ptr)LockResource(hglobalSRGB);
	if(lpSRGB) {
		if( mng_set_srgb(This->mng, MNG_TRUE)) {
			warn(This,"mng_set_srgb failed");
			return 0;
		}
		if( mng_set_outputprofile2(This->mng, SRGB_PROFILE_LENGTH, lpSRGB) ) {
			warn(This,"mng_set_outputprofile2 failed");
			return 0;
		}
	}
	else {
		warn(This,"Could not set sRGB color profile");
		return 0;
	}
	return 1;
}


// return 1 if okay
int my_init_mng(PluginInstance *This)
{
	mng_retcode rv;
	int err;

	This->mng = mng_initialize((mng_int32)This,memallocfunc,memfreefunc,NULL);

	init_color_management(This);

	err=0;
	rv=mng_setcb_openstream    (This->mng, callback_openstream   ); if(rv) err++;
	rv=mng_setcb_closestream   (This->mng, callback_closestream  ); if(rv) err++;
	rv=mng_setcb_readdata      (This->mng, callback_readdata     ); if(rv) err++;
	rv=mng_setcb_processheader (This->mng, callback_processheader); if(rv) err++;
	rv=mng_setcb_getcanvasline (This->mng, callback_getcanvasline); if(rv) err++;
	rv=mng_setcb_refresh       (This->mng, callback_refresh      ); if(rv) err++;
	rv=mng_setcb_gettickcount  (This->mng, callback_gettickcount ); if(rv) err++;
	rv=mng_setcb_settimer      (This->mng, callback_settimer     ); if(rv) err++;
	if(err) {
		warn(This,"Error setting libmng callback functions");
		return 0;
	}

	rv=mng_set_bgcolor (This->mng, This->bg_r, This->bg_g, This->bg_b);

	handle_read_error(This, mng_readdisplay(This->mng) );
	return 1;
}


/* Global initialization */
NPError NPP_Initialize(void)
{
	hInst=GetModuleHandle(DLLFILENAME);
	if(!hInst) {
		warn(NULL,"Cannot load resources. Make sure plug-in file is named %s",DLLFILENAME);
	}
	hmenuContext=LoadMenu(hInst,"CONTEXTMENU");
	return NPERR_NO_ERROR;
}

/* Global shutdown */
void NPP_Shutdown(void)
{
	if(hmenuContext) DestroyMenu(hmenuContext);
}


uchar gethex(const char *s)
{
	int v0,v1;
	v0=v1=0; 
	if(s[0]>='a' && s[0]<='f') v0=s[0]-87;
	if(s[0]>='A' && s[0]<='F') v0=s[0]-55;
	if(s[0]>='0' && s[0]<='9') v0=s[0]-48;
	if(s[1]>='a' && s[1]<='f') v1=s[1]-87;
	if(s[1]>='A' && s[1]<='F') v1=s[1]-55;
	if(s[1]>='0' && s[1]<='9') v1=s[1]-48;
	return (uchar)(v0*16+v1);
}

void hexcolor2rgb(const char *s, mng_uint16 *r, mng_uint16 *g, mng_uint16 *b)
{
	if(strlen(s)!=7) return;
	if(s[0]!='#') return;
	(*r)= gethex(&s[1]); (*r)= ((*r)<<8)|(*r);
	(*g)= gethex(&s[3]); (*g)= ((*g)<<8)|(*g);
	(*b)= gethex(&s[5]); (*b)= ((*b)<<8)|(*b);
}


/* Once-per-instance initialization */
NPError NPP_New(NPMIMEType pluginType,NPP instance,uint16 mode,
		int16 argc,char* argn[],char* argv[],NPSavedData* saved)
{
	PluginInstance* This;
	int i;
	
	if (instance == NULL) {
		return NPERR_INVALID_INSTANCE_ERROR;
	}
	/* instance->pdata = NPN_MemAlloc(sizeof(PluginInstance)); */
	instance->pdata = GlobalAlloc(GPTR,sizeof(PluginInstance));

	This = (PluginInstance*) instance->pdata;
	if (This == NULL) {
	    return NPERR_OUT_OF_MEMORY_ERROR;
	}

	This->bg_r = This->bg_g = This->bg_b = 0xffff;

	/* examine the <embed> tag arguments */
	for(i=0;i<argc;i++) {
		if(!_stricmp(argn[i],"bgcolor")) {
			hexcolor2rgb(argv[i],&This->bg_r,&This->bg_g,&This->bg_b);
		}
	}

	/* record some info for later lookup */
	This->fWindow = NULL;
	This->fMode = mode;
	
	This->fhWnd = NULL;
	This->fDefaultWindowProc = NULL;
	This->instance = instance;  /* save the instance id for reverse lookups */

	This->loadstate = STATE_INIT;
	This->mng=0;
	This->lpdib=NULL;
	strcpy(This->url,"");
	This->frozen=0;
	This->needresume=0;
	This->dibsize = This->filesize = 0;

//	my_init_mng(This);

	return NPERR_NO_ERROR;
}

NPError NPP_Destroy(NPP instance, NPSavedData** save)
{
	PluginInstance* This;

	if (instance == NULL) return NPERR_INVALID_INSTANCE_ERROR;
	This = (PluginInstance*) instance->pdata;

	if(!This) return NPERR_INVALID_INSTANCE_ERROR;

	if(This->mng) {
		mng_cleanup(&This->mng); 
		This->mng=0;
	}
	if(This->lpdib) {
		GlobalFree(This->lpdib);
		This->lpdib=NULL;
	}
	if(This->mngdata) {
		GlobalFree(This->mngdata);
		This->mngdata=NULL;
	}

	if( This->fhWnd ) { // un-subclass the plugin window
		SetWindowLong( This->fhWnd, GWL_WNDPROC, (LONG)This->fDefaultWindowProc);
		This->fDefaultWindowProc = NULL;
		This->fhWnd = NULL;
	}


	if (This != NULL) {
		if(instance->pdata) GlobalFree(instance->pdata);
		instance->pdata = NULL;
	}

	return NPERR_NO_ERROR;
}

jref NPP_GetJavaClass(void)
{
	return NULL;
}

/* Browser is providing us with a window */
NPError NPP_SetWindow(NPP instance, NPWindow* window)
{
	NPError result = NPERR_NO_ERROR;
	PluginInstance* This;

	if (instance == NULL) return NPERR_INVALID_INSTANCE_ERROR;

	This = (PluginInstance*) instance->pdata;

	if( This->fhWnd != NULL ) {   /* If we already have a window... */

		if( (window == NULL) || ( window->window == NULL ) ) {
			/* There is now no window to use. get rid of the old
			 * one and exit. */
			SetWindowLong( This->fhWnd, GWL_WNDPROC, (LONG)This->fDefaultWindowProc);
			This->fDefaultWindowProc = NULL;
			This->fhWnd = NULL;
			This->fWindow=window;
			return NPERR_NO_ERROR;
		}

		else if ( This->fhWnd == (HWND) window->window ) {
			/* The new window is the same as the old one. Redraw and get out. */
			This->fWindow=window;

			InvalidateRect( This->fhWnd, NULL, FALSE );
			/* UpdateWindow( This->fhWnd ); */
			return NPERR_NO_ERROR;
		}
		else {
			/* Unsubclass the old window, so that we can subclass the new
			 * one later. */
			SetWindowLong( This->fhWnd, GWL_WNDPROC, (LONG)This->fDefaultWindowProc);
			This->fDefaultWindowProc = NULL;
			This->fhWnd = NULL;
		}
	}
	else if( (window == NULL) || ( window->window == NULL ) ) {
		/* We can just get out of here if there is no current
		 * window and there is no new window to use. */
		This->fWindow=window;

		return NPERR_NO_ERROR;
	}

	/* Subclass the new window so that we can begin drawing and
	 * receiving window messages. */
	This->fDefaultWindowProc = (WNDPROC)SetWindowLong( (HWND)window->window, GWL_WNDPROC, (LONG)PluginWindowProc);
	This->fhWnd = (HWND) window->window;
	SetProp( This->fhWnd, gInstanceLookupString, (HANDLE)This);

	This->fWindow = window;

	InvalidateRect( This->fhWnd, NULL, TRUE );
	UpdateWindow( This->fhWnd );

	return result;
}

// browser is announcing its intent to send data to us
NPError NPP_NewStream(NPP instance,NPMIMEType type,NPStream *stream, 
	      NPBool seekable,uint16 *stype) {
	PluginInstance* This;

	if(instance==NULL)
		return NPERR_INVALID_INSTANCE_ERROR;

	This = (PluginInstance*) instance->pdata;
	if(!This)
		return NPERR_GENERIC_ERROR;

	/* save the URL for later */
	Strncpy(This->url,stream->url,MAX_PATH);


	This->libmngpos=0;
	This->bytesloaded=0;
	This->bytesalloc=0;
	This->byteswanted=0;
	This->mngdata=NULL;

	// if we know the total length of the stream in advance 
	// (most of the time we will, hopefully), allocate that amount.
	if(stream->end > 0) {
		This->mngdata = GlobalAlloc(GMEM_FIXED,stream->end);
		This->bytesalloc= stream->end;
	}

	my_init_mng(This);

	// (*stype)=NP_ASFILE; // -- request stream to be given as a file

	return NPERR_NO_ERROR;
}

int32 NPP_WriteReady(NPP instance, NPStream *stream)
{
	/* Number of bytes ready to accept in NPP_Write() */
	/* We can handle any amount, so just return some really big number. */
	return (int32)0X0FFFFFFF;
}

#define ALLOC_CHUNK_SIZE 131072

int32 NPP_Write(NPP instance, NPStream *stream, int32 offset, int32 len, void *buffer)
{
	PluginInstance* This;

	if(!instance) return -1;
	This = (PluginInstance*) instance->pdata;
	if(!This) return -1;
	if(len<1) return len;

	if(offset+len > (int)This->bytesalloc) {  // oops, overflowed our memory buffer
		This->bytesalloc += ALLOC_CHUNK_SIZE;
		if(This->mngdata) {
			This->mngdata=GlobalReAlloc(This->mngdata, This->bytesalloc, 0);
		}
		else {  // first time
			This->mngdata=GlobalAlloc(GMEM_FIXED,This->bytesalloc);
		}
		if(!This->mngdata) {
			warn(This,"Cannot allocate memory for image (%d,%d,%p",offset,len,buffer);
			return -1;
		}
	}

	// now we should have enough room to copy the data to memory

	CopyMemory(&This->mngdata[offset],buffer,len);

	This->bytesloaded = offset+len;

	// now, check if it's time to call mng_read_resume
	if(This->needresume &&
		(This->bytesloaded >= (This->libmngpos + This->byteswanted)) )
	{
		This->needresume=0;
		handle_read_error(This, mng_read_resume(This->mng) );
	}


	return len; // The number of bytes accepted -- we always accept them all.
}

/* DestroyStream gets called after the file has finished loading,
 */
NPError NPP_DestroyStream(NPP instance, NPStream *stream, NPError reason)
{
	PluginInstance* This;
	if(!instance) return NPERR_INVALID_INSTANCE_ERROR;

	This = (PluginInstance*) instance->pdata;
	This->filesize = This->bytesloaded;
	This->loadstate = STATE_LOADED;
	return NPERR_NO_ERROR;
}


void NPP_StreamAsFile(NPP instance, NPStream *stream, const char* fname)
{
	return;
}

// Print embedded plug-in (via the browser's Print command)
void NPP_Print(NPP instance, NPPrint* printInfo)
{
	PluginInstance* This;
	if (instance == NULL) return;
	This = (PluginInstance*) instance->pdata;

	if(printInfo == NULL) {
		// Some browsers (Netscape) set printInfo to NULL to tell the plugin
		// to print in full page mode (this may be a bug).
		// PrintFullPage();  -- full page printing not implemented
		return;
	}
	
	if (printInfo->mode == NP_FULL) {
		/* the plugin is full-page, and the browser is giving it a chance
		 * to print in the manner of its choosing */
		void* platformPrint = printInfo->print.fullPrint.platformPrint;
		NPBool printOne =  printInfo->print.fullPrint.printOne;
		
		/* Setting this to FALSE and returning *should* cause the browser to
		 * call NPP_Print again, this time with mode=NP_EMBED.
		 * However, that doesn't happen with any browser I've ever seen :-(.
		 * Instead of the following line, you will probably need to implement
		 * printing yourself.  You also might as well set pluginPrinted to TRUE,
		 * though every browser I've tested ignores it. */
		printInfo->print.fullPrint.pluginPrinted = FALSE;
		/*  or */
		/*  PrintFullPage();
		 *  printInfo->print.fullPrint.pluginPrinted = TRUE;  */
	}
	else {	// we are embedded, and the browser had provided a printer context
		HDC pdc;
		int prevstretchmode;
		NPWindow* printWindow;
		
		if(This->loadstate < STATE_VALIDFRAME) return;

		printWindow= &(printInfo->print.embedPrint.window);

		/* embedPrint.platformPrint is a Windows device context in disguise */

		/* The definition of NPWindow changed between API verion 0.9 and 0.11,
		 * increasing in size from 28 to 32 bytes. This normally makes it
		 * impossible for version 0.9 browsers to print version 0.11 plugins
		 * (because the platformPrint field ends up at the wrong offset) --
		 * unless the plugin takes special care to detect this situation.
		 * To work around it, if we are compiled with API 0.11 or higher,
		 * and the browser is version 0.9 or earlier, we look for the HDC
		 * 4 bytes earlier, at offset 28 instead of 32 (of the embedPrint
		 * sub-structure).
		 */

		if(sizeof(NPWindow)>28 &&     /* i.e. is plugin API >= 0.11? */
			     HIBYTE(g_pNavigatorFuncs->version)==0 &&
		         LOBYTE(g_pNavigatorFuncs->version)<=9) {
			char *tmpc;
			HDC  *tmph;

			tmpc= (char*)&(printInfo->print.embedPrint);
			tmph= (HDC*)&tmpc[28];
			pdc=  *tmph;
		}
		else {
			pdc= (HDC) (printInfo->print.embedPrint.platformPrint);
		}

		if(!This->lpdib) return;

		prevstretchmode=SetStretchBltMode(pdc,COLORONCOLOR);
		StretchDIBits(pdc,
			printWindow->x,printWindow->y,
			printWindow->width,printWindow->height, /* dest coords */
			0,0,This->lpdibinfo->biWidth, This->lpdibinfo->biHeight,   /* source coords */
			This->lpdibbits, (LPBITMAPINFO)This->lpdib,
			DIB_RGB_COLORS,SRCCOPY);
		if(prevstretchmode) SetStretchBltMode(pdc,prevstretchmode);
	}
	return;
}


/*+++++++++++++++++++++++++++++++++++++++++++++++++
 * NPP_URLNotify:
 * Notifies the instance of the completion of a URL request. 
 +++++++++++++++++++++++++++++++++++++++++++++++++*/
void NPP_URLNotify(NPP instance, const char* url, NPReason reason, void* notifyData)
{
	return;
}


/*+++++++++++++++++++++++++++++++++++++++++++++++++
 * NPP_HandleEvent:
 * With normal windowed plugins, this is used only for Macs.
 +++++++++++++++++++++++++++++++++++++++++++++++++*/
int16 NPP_HandleEvent(NPP instance, void* event)
{
	return 0;
}

/**********************************************************************/

/* Try to make a filename from the url. Caller must provide fn[MAX_PATH] buffer.
 * This function attempts to extract a bitmap filename from a URL,
 * but if it doesn't look like it contains an appropriate name,
 * it leaves it blank. */
void url2filename(char *fn, char *url)
{
	int title,ext,i;

	strcpy(fn,"");
	ext=0;   /* position of the file extention */
	title=0; /* position of the base filename */
	for(i=0;url[i];i++) {
		if(url[i]=='.') ext=i+1;
		if(url[i]=='/') title=i+1;
		if(url[i]==':') title=i+1;
		if(url[i]=='=') title=i+1;
	}

	if (!_stricmp(&url[ext],"mng") ||
		!_stricmp(&url[ext],"jng") ||
		!_stricmp(&url[ext],"png") )
	{
		Strncpy(fn,&url[title],MAX_PATH);
	}
}


/* Write the image to a local file  */
void SaveImage(PluginInstance *This)
{
	OPENFILENAME ofn;
	char fn[MAX_PATH];
	HANDLE hfile;
	BOOL b;
	mng_imgtype t;
	DWORD byteswritten;

	if(!This->mng || This->loadstate<STATE_LOADED ||
		This->bytesloaded != This->filesize)
	{
		warn(This,"Image not loaded -- can't save");
		return;
	}

	if(strlen(This->url)) {
		url2filename(fn,This->url);
	}
	else {
		strcpy(fn,"");
	}

	ZeroMemory(&ofn,sizeof(OPENFILENAME));
	ofn.lStructSize=sizeof(OPENFILENAME);
	ofn.hwndOwner=This->fhWnd;
	ofn.nFilterIndex=1;
	ofn.lpstrTitle="Save Image As...";
	ofn.lpstrFile=fn;
	ofn.nMaxFile=MAX_PATH;
	ofn.Flags=OFN_PATHMUSTEXIST|OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT;

	t=mng_get_sigtype(This->mng);
	if(t==mng_it_png) {
		ofn.lpstrDefExt="png";  // FIXME also give an option of MNG
		ofn.lpstrFilter="PNG (*.png)\0*.png\0\0";
	}
	else if(t==mng_it_jng) {
		ofn.lpstrDefExt="jng";  // FIXME also give an option of MNG
		ofn.lpstrFilter="JNG (*.jng)\0*.jng\0\0";
	}
	else {
		ofn.lpstrFilter="MNG (*.mng)\0*.mng\0\0";
		ofn.lpstrDefExt="mng";
	}

	if(GetSaveFileName(&ofn)) {
		// save to filename: ofn.lpstrFile
		hfile=CreateFile(ofn.lpstrFile,GENERIC_WRITE,FILE_SHARE_READ,
			NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);
		if(hfile==INVALID_HANDLE_VALUE) {
			warn(This,"Unable to write file");
		}
		else {
			b=WriteFile(hfile, This->mngdata, This->filesize,
				&byteswritten,NULL);
			if(!b || byteswritten != This->filesize) {
				warn(This,"Error writing file");
			}
			CloseHandle(hfile);
		}
	}
}


void CopyToClipboard(PluginInstance *This,unsigned char *mem,int size,UINT format)
{
	HGLOBAL hClip;
	LPVOID lpClip;

	if(!mem) return;

	if(!OpenClipboard(NULL)) {
		warn(This,"Can't open the clipboard");
		return;
	}

	if(EmptyClipboard()) {
		hClip=GlobalAlloc(GMEM_ZEROINIT|GMEM_MOVEABLE|GMEM_DDESHARE,size);
		lpClip=GlobalLock(hClip);
		if(lpClip) {
			CopyMemory(lpClip,mem,size);
			GlobalUnlock(hClip);
			if(!SetClipboardData(format,hClip)) {
				warn(This,"Can't set clipboard data");
			}
		}
		else {
			warn(This,"Can't allocate memory for clipboard");
		}
	}
	else {
		warn(This,"Can't clear the clipboard");
	}
	CloseClipboard();
}



void AboutDialog(PluginInstance *This)
{
	DialogBoxParam(hInst,"ABOUTDLG",This->fhWnd,(DLGPROC)DlgProcAbout,(LPARAM)This);
}

void ContextMenu(PluginInstance *This, int x, int y, HWND hwnd)
{
	int gotimage;
	HMENU sub;
	int cmd;
//	mng_retcode rv;

	sub=GetSubMenu(hmenuContext,0);

	gotimage = (This->lpdib?MF_ENABLED:MF_GRAYED);
//	EnableMenuItem(sub,ID_FREEZE,MF_BYCOMMAND|(This->mng?MF_ENABLED:MF_GRAYED));
//	EnableMenuItem(sub,ID_RESTARTMNG,MF_BYCOMMAND|(This->mng?MF_ENABLED:MF_GRAYED));
	EnableMenuItem(sub,ID_COPYIMAGE,MF_BYCOMMAND|(This->lpdib?MF_ENABLED:MF_GRAYED));
	EnableMenuItem(sub,ID_SAVEAS,MF_BYCOMMAND|(This->lpdib?MF_ENABLED:MF_GRAYED));
//	if(This->lpdib) {
//		CheckMenuItem(sub,ID_FREEZE,MF_BYCOMMAND|(This->frozen?MF_CHECKED:MF_UNCHECKED));
//	}

	cmd=TrackPopupMenuEx(sub, TPM_LEFTALIGN|TPM_TOPALIGN|TPM_NONOTIFY|TPM_RETURNCMD|
		TPM_RIGHTBUTTON,x,y,hwnd,NULL);

	switch(cmd) {

#if 0                // not fully supported by libmng yet
	case ID_FREEZE:
		This->frozen = !This->frozen;
		if(This->frozen) {
			KillTimer(This->fhWnd,1);
			mng_display_freeze(This->mng);
		}
		else {
			handle_read_error(This, mng_display_resume(This->mng) );

		}
		break;

	case ID_RESTARTMNG:
		//if(!This->frozen) {
		//	KillTimer(This->fhWnd,1);
		//	mng_display_freeze(This->mng);
		//}
		This->frozen=0;
		mng_display_reset(This->mng);
		//mng_display_resume(This->mng);
		break;
#endif

	case ID_SAVEAS:
		SaveImage(This);
		break;
	case ID_COPYIMAGE:
		if(This->lpdib) {
			CopyToClipboard(This,(unsigned char*)This->lpdib,This->dibsize,CF_DIB);
		}
		else {
			warn(This,"No image to copy");
		}
		break;
	case ID_COPYURL:
		if(strlen(This->url)) {
			CopyToClipboard(This,This->url,strlen(This->url)+1,CF_TEXT);
		}
		else {
			warn(This,"No link to copy");
		}
		break;
	case ID_VIEWIMAGE:
		if(strlen(This->url)) 
			NPN_GetURL(This->instance,This->url,"_self");
		break;
	case ID_ABOUT:   AboutDialog(This); break;

	}
}

/*+++++++++++++++++++++++++++++++++++++++++++++++++
 * PluginWindowProc
 * Handle the Windows window-event loop.
 +++++++++++++++++++++++++++++++++++++++++++++++++*/
LRESULT CALLBACK PluginWindowProc( HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam)
{
	PluginInstance* This = (PluginInstance*) GetProp(hWnd, gInstanceLookupString);

	if(!This) return DefWindowProc( hWnd, Msg, wParam, lParam);

	switch(Msg) {
//	case WM_ERASEBKGND:
//		return 1;

	case WM_CONTEXTMENU:
		ContextMenu(This,LOWORD(lParam),HIWORD(lParam), hWnd);
		return 0;

	case WM_PAINT:
		{
			PAINTSTRUCT paintStruct;
			HDC hdc;
			RECT rect;

			hdc = BeginPaint( hWnd, &paintStruct );

			GetClientRect(hWnd,&rect);

			if(This && This->lpdib) {

				StretchDIBits(hdc,
					0,0,This->lpdibinfo->biWidth,This->lpdibinfo->biHeight,
					0,0,This->lpdibinfo->biWidth,This->lpdibinfo->biHeight,
					&((BYTE*)(This->lpdib))[sizeof(BITMAPINFOHEADER)],
					(LPBITMAPINFO)This->lpdib,DIB_RGB_COLORS,SRCCOPY);
			}


			EndPaint( hWnd, &paintStruct );
		}
		return 0;

	case WM_TIMER:
		KillTimer(hWnd,1);     // do I need to do this?
		if(This->mng) {
			handle_read_error(This, mng_display_resume(This->mng) );
		}
		return 0;

	}

	/* Forward unprocessed messages on to their original destination
	 * (the window proc we replaced) */
	return This->fDefaultWindowProc(hWnd, Msg, wParam, lParam);
}


LRESULT CALLBACK DlgProcAbout(HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam)
{
	char buf[4096],buf2[1024];

	switch(Msg) {
	case WM_INITDIALOG:
		{
			DWORD tabs[1];

			PluginInstance *This=(PluginInstance*)lParam;

			tabs[0]= 60;
			SendDlgItemMessage(hWnd,IDC_IMGINFO,EM_SETTABSTOPS,(WPARAM)1,(LPARAM)tabs);

			sprintf(buf,"MNGPLG Plug-in, Version %s\r\n%s"
#ifdef _DEBUG
				" DEBUG BUILD"
#endif
				"\r\nBy Jason Summers\r\n\r\n",VERS,__DATE__);

			sprintf(buf2,"Based on libmng by Gerard Juyn.\r\n");
			strcat(buf,buf2);

			sprintf(buf2,"libmng version: %s\r\n\r\n",mng_version_text());
			strcat(buf,buf2);

			sprintf(buf2,"Uses the zlib compression library.\r\n\r\n");
			strcat(buf,buf2);

			sprintf(buf2,"This software is based in part on the work of the "
				"Independent JPEG Group.\r\n\r\n");
			strcat(buf,buf2);

			sprintf(buf2,"Uses the lcms color management library by Marti Maria.");
			strcat(buf,buf2);


			SetDlgItemText(hWnd,IDC_PRGINFO,buf);


			sprintf(buf,"URL:\t%s\r\n",This->url);

			if(This->lpdib) {
				sprintf(buf2,"Dimensions:\t%d x %d\r\n",This->lpdibinfo->biWidth,
					This->lpdibinfo->biHeight);
				strcat(buf,buf2);
			}

			if(This->filesize) {
				sprintf(buf2,"File size:\t%u bytes\r\n",This->filesize);
				strcat(buf,buf2);
			}

//			if(This->loadstate >= STATE_LOADED) {
//				sprintf(buf2,"Frame count:\t%u\r\n",mng_get_framecount(This->mng));
//				strcat(buf,buf2);
//			}

			SetDlgItemText(hWnd,IDC_IMGINFO,buf);
		}
		return(TRUE);
	case WM_CLOSE:
		EndDialog(hWnd,0);
		return(TRUE);
	case WM_COMMAND:
		switch(wParam) {
		case IDOK:
		case IDCANCEL:
			EndDialog(hWnd,0);
			return(TRUE);
		}
	}
	return(FALSE);
}
